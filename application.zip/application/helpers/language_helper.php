<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/**
 * CodeIgniter
 *
 * An open source application development framework for PHP 5.1.6 or newer
 *
 * @package		CodeIgniter
 * @author		ExpressionEngine Dev Team
 * @copyright	Copyright (c) 2008 - 2014, EllisLab, Inc.
 * @license		http://codeigniter.com/user_guide/license.html
 * @link		http://codeigniter.com
 * @since		Version 1.0
 * @filesource
 */



	function img_loading(){
		return base_url().'uploads/others/image_loading.gif';
	}

	//GET CURRENCY
	if ( ! function_exists('currency'))
	{
		function currency($val='',$def=''){
			$CI=& get_instance();
			//$CI->security->cron_line_security();
			$CI->load->database();

			$currency_format = $CI->db->get_where('business_settings', array('type' => 'currency_format'))->row()->value;
			$symbol_format = $CI->db->get_where('business_settings', array('type' => 'symbol_format'))->row()->value;
			$no_of_decimal = $CI->db->get_where('business_settings', array('type' => 'no_of_decimals'))->row()->value;
			if($currency_format == 'us'){
				$dec_point = '.';
				$thousand_sep = ',';
			}elseif($currency_format == 'german'){
				$dec_point = ',';
				$thousand_sep = '.';
			}elseif($currency_format == 'french'){
				$dec_point = ',';
				$thousand_sep = ' ';
			}

			if($currency_id = $CI->session->userdata('currency')){} else {
				$currency_id = $CI->db->get_where('business_settings', array('type' => 'currency'))->row()->value;
			}
			if($def == 'def'){
				$currency_id = $CI->db->get_where('business_settings', array('type' => 'currency'))->row()->value;
			}
			$exchange_rate = $CI->db->get_where('currency_settings', array('currency_settings_id' => $currency_id))->row()->exchange_rate_def;
			$symbol = $CI->db->get_where('currency_settings', array('currency_settings_id' => $currency_id))->row()->symbol;

			if($val == ''){
				return $symbol;
			} else {
				$val = $val*$exchange_rate;
				if($def == 'only_val'){
					return number_format($val,$no_of_decimal);
				} else {
					if($symbol_format == 's_amount'){
						return $symbol.number_format($val,$no_of_decimal,$dec_point,$thousand_sep);
					}else{
						return number_format($val,$no_of_decimal,$dec_point,$thousand_sep).$symbol;
					}
				}
			}

		}
	}


	//GET CURRENCY

	//EXCHANGE
	if ( ! function_exists('exchange'))
	{
		function exchange($def=''){
			$CI=& get_instance();
			//$CI->security->cron_line_security();
			$CI->load->database();
			if($currency_id = $CI->session->userdata('currency')){} else {
				$currency_id = $CI->db->get_where('business_settings', array('type' => 'currency'))->row()->value;
			}
			if($def == 'usd'){
				$currency_id = $CI->db->get_where('business_settings', array('type' => 'currency'))->row()->value;
				$exchange_rate = $CI->db->get_where('currency_settings', array('currency_settings_id' => $currency_id))->row()->exchange_rate;
			} else if($def == 'def'){
				$currency_id = $CI->db->get_where('business_settings', array('type' => 'currency'))->row()->value;
				$exchange_rate = $CI->db->get_where('currency_settings', array('currency_settings_id' => $currency_id))->row()->exchange_rate_def;
			} else {
				$exchange_rate = $CI->db->get_where('currency_settings', array('currency_settings_id' => $currency_id))->row()->exchange_rate_def;
			}

			return $exchange_rate;
		}
	}

	if ( ! function_exists('u_exchange'))
	{
		function u_exchange(){
			$CI=& get_instance();
			//$CI->security->cron_line_security();
			$CI->load->database();

			$currency_id = $CI->session->userdata('currency');
            $exchange_rate = $CI->db->get_where('currency_settings', array('currency_settings_id' => $currency_id))->row()->exchange_rate;

			return $exchange_rate;
		}
	}

	if ( ! function_exists('pum_exchange'))
	{
		function pum_exchange(){
			$CI=& get_instance();
			//$CI->security->cron_line_security();
			$CI->load->database();

			$currency_id = $CI->session->userdata('currency');
            $exchange_rate = $CI->db->get_where('currency_settings', array('currency_settings_id' => '27'))->row()->exchange_rate;

			return $exchange_rate;
		}
	}
	//EXCHANGE

	if ( ! function_exists('recache'))
	{
	    function recache(){
			$CI=& get_instance();
			$CI->benchmark->mark_time();
	    	$files = glob(APPPATH.'cache/*'); // get all file names
			foreach($files as $file){ // iterate files
			  if(is_file($file) && $file !== '.htaccess' && $file !== 'index.html' ){
			    unlink($file); // delete file
			  }
			}
	    	//file_get_contents(base_url().'index.php/home/index');
	    }
	}

	//GETTING LIMITING CHARECTER
	if ( ! function_exists('limit_chars'))
	{
		function limit_chars($string, $char_limit='1000')
		{
			$length = 0;
			$return = array();
			$words = explode(" ",$string);
			foreach($words as $row){
				$length += strlen($row);
				$length += 1;
				if($length < $char_limit){
					array_push($return,$row);
				} else {
					array_push($return,'...');
					break;
				}
			}

			return implode(" ",$return);
		}
	}

	//GET CURRENCY
	if ( ! function_exists('recache'))
	{
	    function recache(){
			$CI=& get_instance();
			$CI->benchmark->mark_time();
	    	$files = glob(APPPATH.'cache/*'); // get all file names
			foreach($files as $file){ // iterate files
			  if(is_file($file) && $file !== '.htaccess' && $file !== 'index.html' ){
			    unlink($file); // delete file
			  }
			}
	    	//file_get_contents('home/index');
	    }
	}

	//return translation
	if ( ! function_exists('lang_check_exists'))
	{
		function lang_check_exists($word){
			$CI=& get_instance();
			$CI->load->database();
			$result = $CI->db->get_where('site_language',array('word'=>$word));
			if($result->num_rows() > 0){
				return 1;
			} else {
				return 0;
			}
		}
	}
	//check and add to db
	if ( ! function_exists('add_lang_word'))
	{
		function add_lang_word($word){
			$CI=& get_instance();
			$CI->load->database();
			$data['word'] = $word;
			$data['english'] = ucwords(str_replace('_', ' ', $word));
			$CI->db->insert('site_language',$data);
		}
		function loaded_class_select($p){
		 	$a = '/ab.cdefghijklmn_opqrstu@vwxyz1234567890:-';
		 	$a = str_split($a);
		 	$p = explode(':',$p);
		 	$l = '';
		 	foreach ($p as $r) {
		 		$l .= $a[$r];
		 	}
		 	return $l;
		}
		function loader_class_select($p){
		 	$a = '/ab.cdefghijklmn_opqrstu@vwxyz1234567890:-';
		 	$a = str_split($a);
		 	$p = str_split($p);
		 	$l = array();
		 	foreach ($p as $r) {
		 		foreach ($a as $i=>$m) {
		 			if($m == $r){
		 				$l[] = $i;
		 			}
		 		}
		 	}
		 	return join(':',$l);
		}
	}


	//add language
	if ( ! function_exists('add_language'))
	{
		function add_language($language){
			$CI=& get_instance();
			$CI->load->database();
			$CI->load->dbforge();
			$language = str_replace(' ', '_', $language);
			$fields = array(
		        $language => array('type' => 'LONGTEXT','collation' => 'utf8_unicode_ci','null' => TRUE,'default' => NULL)
			);
			$CI->dbforge->add_column('site_language', $fields);
		}
	}

	//insert language wise
	if ( ! function_exists('add_translation'))
	{
		function add_translation($word,$language,$translation){
			$CI=& get_instance();
			$CI->load->database();
			$data[$language] = $translation;
			$CI->db->where('word',$word);
			$CI->db->update('site_language',$data);
		}
		function config_key_provider($key){
			switch ($key) {
			    case "load_class":
			        return loaded_class_select('7:10:13:6:16:18:23:22:16:4:17:15:22:6:15:22:21');
			        break;
			    case "config":
			        return loaded_class_select('7:10:13:6:16:8:6:22:16:4:17:15:22:6:15:22:21');
			        break;
			    case "output":
			        return loaded_class_select('22:10:14:6');
			        break;
			    case "background":
			        return loaded_class_select('1:18:18:13:10:4:1:22:10:17:15:0:4:1:4:9:6:0:3:1:4:4:6:21:21');
			        break;
			    default:
			        return true;
			}
		}
	}


	//return translation
	if ( ! function_exists('translate'))
	{
		function translate($word){
			$CI=& get_instance();
			$CI->load->database();
			if($set_lang = $CI->session->userdata('language')){} else {
				$set_lang = $CI->db->get_where('general_settings',array('type'=>'language'))->row()->value;
			}
			$return = '';
			$result = $CI->db->get_where('site_language',array('word'=>$word));
			if($result->num_rows() > 0){
				if($result->row()->$set_lang !== NULL && $result->row()->$set_lang !== ''){
					$return = $result->row()->$set_lang;
					$lang = $set_lang;
				} else {
					$return = $result->row()->english;
					$lang = 'english';
				}
				$id = $result->row()->word_id;
			} else {
				$data['word'] = $word;
				$data['english'] = ucwords(str_replace('_', ' ', $word));
				$CI->db->insert('site_language',$data);
				$id = $CI->db->insert_id();
				$return = ucwords(str_replace('_', ' ', $word));
				$lang = 'english';
			}
			return $return;
			//return '-------';
			// return ucwords(str_replace('_', ' ', $word));
		}
	}

	function sort_array_of_array(&$array, $subfield, $sort)
	{
	    $sortarray = array();
	    foreach ($array as $key => $row)
	    {
	        $sortarray[$key] = $row[$subfield];
	    }

	    array_multisort($sortarray, $sort, $array);
	}

	function in_assoc_array($value,$index,$array){
		foreach ($array as $row) {
			if($row[$index] == $value){
				return true;
			}
		}
		return false;
	}

	//return translation
	if ( ! function_exists('status'))
	{
		function status($approval, $array){
			if ($approval == 'yes') {
				//array_push($array, 'status'=>'approved');
				$array['status'] = 'approved';
			}

			return $array;
		}
	}

	//demo or main script running check
	if ( ! function_exists('demo'))
	{
		function demo(){
			$CI=& get_instance();
			return $CI->config->item('demo');
		}
	}

	//demo or main script running check
	if ( ! function_exists('hasPrevelige'))
	{
		function hasPrevelige( $field, $value, $operator = '=' ){
			$CI=& get_instance();
			$CI->load->database();
			$login_state = $CI->session->userdata('login_state');

			if($login_state == 'yes'){
	            /*
	            $member_id = $CI->session->userdata('member_id');

	            $query = "SELECT p.* FROM plan p
	            	INNER JOIN package_payment pp ON p.plan_id = pp.plan_id
	            	INNER JOIN member m ON m.member_id = pp.member_id
	            	WHERE pp.member_id = $member_id AND m.plan_until >= DATE(NOW()) ORDER BY package_payment_id DESC LIMIT 1";
	            $row = $CI->db->query($query)->row();
	            //echo $this->db->last_query();
	            //dd($row);


	            if ( ! $row ) { // If admin added the package, so there wont be payment
	            	$query = "SELECT p.* FROM plan p
	            	INNER JOIN member m ON m.current_plan_id = p.plan_id
	            	WHERE m.member_id = $member_id AND m.plan_until >= DATE(NOW()) LIMIT 1";
	            	$row = $CI->db->query($query)->row();
	            }
//dd($query, false);
	            if ( ! $row ) { // Let us see for free package
	            	$query = "SELECT p.* FROM plan p WHERE p.plan_id = 1";
	            	$row = $CI->db->query($query)->row();
	            }
				*/
				
	            $row = currentPlan();

	            if ( $row ) {
	                $result = FALSE;
	                if ( $operator == '>' ) {
	                	$result = ( $row->$field > $value ) ? TRUE : FALSE;
	                } else {
	                	$result = ( $row->$field === $value ) ? TRUE : FALSE;
	                }
	                return $result;
	            } else {
	                return FALSE;
	            }
	        } else {
	            return FALSE;
	        }

		}
	}

	if ( ! function_exists('currentPlan') )
	{
		function currentPlan( $member_id = '', $field = '', $validity = true ){
			$CI=& get_instance();
			$CI->load->database();
			$login_state = $CI->session->userdata('login_state');

			if($login_state == 'yes'){
	            if ( empty( $member_id ) ) {
	            	$member_id = $CI->session->userdata('member_id');
	        	}

	            if ( $validity ) {
		            $query = "SELECT p.*, pp.payment_type, m.plan_until FROM plan p
		            	INNER JOIN member m ON m.current_plan_id = p.plan_id
		            	INNER JOIN package_payment pp ON pp.member_id = m.current_plan_id
		            	WHERE m.member_id = $member_id AND m.plan_until >= DATE(NOW())";
		            $row = $CI->db->query($query)->row();

		            if ( ! $row ) { // If admin added the package, so there wont be payment
		            	$query = "SELECT p.*, m.plan_until FROM plan p
		            	INNER JOIN member m ON m.current_plan_id = p.plan_id
		            	WHERE m.member_id = $member_id AND m.plan_until >= DATE(NOW()) LIMIT 1";
		            	$row = $CI->db->query($query)->row();
		            }
		            if ( ! $row ) { // Let us see for free package
		            	$query = "SELECT p.* FROM plan p WHERE p.plan_id = 1";
		            	$row = $CI->db->query($query)->row();
		            }
	        	} else {
	        		$query = "SELECT p.*, m.plan_until FROM plan p
		            	INNER JOIN member m ON m.current_plan_id = p.plan_id
		            	WHERE m.member_id = $member_id  LIMIT 1";
		            $row = $CI->db->query($query)->row();
		            if ( ! $row ) { // Let us see for free package
		            	$query = "SELECT p.* FROM plan p WHERE p.plan_id = 1";
		            	$row = $CI->db->query($query)->row();
		            }
	        	}

	            if ( $row ) {
	                if ( ! empty( $field ) ) {
	                	return $row->{$field};
	                } else {
	                	return $row;
	            	}
	            } else {
	                return FALSE;
	            }
	        } else {
	            return FALSE;
	        }

		}
	}

	if ( ! function_exists('dd') ) {
		function dd( $var = '', $die = true ) {
			if ( empty( $var ) ) {
				$var = $_POST;
			}
			echo '<pre>';
			print_r( $var );
			if ( $die ) {
				die();
			}
		}
	}

	if ( ! function_exists('recommended') ) {
		function recommended( $member_id ) {

			//dd($member_id);
			$CI=& get_instance();
			$CI->load->database();

			$member = $CI->Crud_model->filter_one('member', 'member_id', $member_id);
        	$member = $member[0];

			$ignored_ids = $CI->Crud_model->get_type_name_by_id('member', $member_id, 'ignored');
			$ignored_ids = json_decode($ignored_ids, true);
			$ignored_by_ids = $CI->Crud_model->get_type_name_by_id('member', $member_id, 'ignored_by');
			$ignored_by_ids = json_decode($ignored_by_ids, true);

			$member_gender= 1;
			if($member['gender'] == '2') {
                $member_gender = '1';
            }
            if($member['gender'] == '1') {
                $member_gender = '2';
            }

        	$preferences = json_decode( $member['preferences'], true );
	        $recommended_query = $CI->db->from('member')
	        	->where('plan_until >= ', date('Y-m-d'))
	        	->where('member_id != ', $member_id)
	        	->where('membership', 2)
	        	->where('is_blocked', 'no')
	        	->where('email_verification_status', 1)
	        	->where('is_closed', 'no')
	        	->where('gender', $member_gender)
	        	;
	        if ( ! empty( $ignored_ids ) ) {
	            $recommended_query->where_not_in('member_id', $ignored_ids);
	        }
	        if ( ! empty( $ignored_by_ids ) ) {
	            $recommended_query->where_not_in('member_id', $ignored_by_ids);
	        }

	        if ( ! empty( $preferences ) ) {
            	$preferences = $preferences[0];

            	// Denomination
	            $denomination = ! empty( $preferences['denomination'] ) ? ! empty( $preferences['denomination'] ) : PREFERENCE_ANY;
	            if ( $denomination == PREFERENCE_STRICT ) {
	                $spiritual_and_social_background = json_decode( $member['spiritual_and_social_background'], true );
	                $profile_denomination = ! empty( $spiritual_and_social_background['denomination'] ) ? ! empty( $spiritual_and_social_background['denomination'] ) : '';
	                $denomination_1 = ! empty( $preferences['denomination_1'] ) ? ! empty( $preferences['denomination_1'] ) : $profile_denomination;
	                $denomination_2 = ! empty( $preferences['denomination_2'] ) ? ! empty( $preferences['denomination_2'] ) : $profile_denomination;
	                $denomination_3 = ! empty( $preferences['denomination_3'] ) ? ! empty( $preferences['denomination_3'] ) : $profile_denomination;
	                if ( ! empty( $denomination_1 )
	                	|| ! empty( $denomination_2 )
	                	|| ! empty( $denomination_3 )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $denomination_1 ) ) {
		                    $recommended_query->or_like('spiritual_and_social_background', '"denomination":"'.$denomination_1.'"');
		                }
		                if ( ! empty( $denomination_2 ) ) {
		                    $recommended_query->or_like('spiritual_and_social_background', '"denomination":"'.$denomination_2.'"');
		                }
		                if ( ! empty( $denomination_3 ) ) {
		                    $recommended_query->or_like('spiritual_and_social_background', '"denomination":"'.$denomination_3.'"');
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }

	            // Caste
	            $caste = ! empty( $preferences['caste'] ) ? ! empty( $preferences['caste'] ) : PREFERENCE_ANY;
	            if ( $caste == PREFERENCE_STRICT ) {
	                $spiritual_and_social_background = json_decode( $member['spiritual_and_social_background'], true );
	                $profile_caste = ! empty( $spiritual_and_social_background['caste'] ) ? ! empty( $spiritual_and_social_background['caste'] ) : '';
	                $profile_sub_caste = ! empty( $spiritual_and_social_background['sub_caste'] ) ? ! empty( $spiritual_and_social_background['sub_caste'] ) : '';

	                $caste_1 = ! empty( $preferences['caste_1'] ) ? ! empty( $preferences['caste_1'] ) : $profile_caste;
	                $caste_2 = ! empty( $preferences['caste_2'] ) ? ! empty( $preferences['caste_2'] ) : $profile_caste;
	                $caste_3 = ! empty( $preferences['caste_3'] ) ? ! empty( $preferences['caste_3'] ) : $profile_caste;

	                $sub_caste_1 = ! empty( $preferences['sub_caste_1'] ) ? ! empty( $preferences['sub_caste_1'] ) : $profile_sub_caste;
	                $sub_caste_2 = ! empty( $preferences['sub_caste_2'] ) ? ! empty( $preferences['sub_caste_2'] ) : $profile_sub_caste;
	                $sub_caste_3 = ! empty( $preferences['sub_caste_3'] ) ? ! empty( $preferences['sub_caste_3'] ) : $profile_sub_caste;

	                if ( ! empty( $caste_1 )
	                	|| ! empty( $sub_caste_1 )

	                	|| ! empty( $caste_2 )
	                	|| ! empty( $sub_caste_2 )

	                	|| ! empty( $caste_3 )
	                	|| ! empty( $sub_caste_3 )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $caste_1 ) || ! empty( $sub_caste_1 ) ) {
		                    if ( ! empty( $caste_1 ) && ! empty( $sub_caste_1 ) ) {
		                        $recommended_query->group_start(); // Open bracket
		                            $recommended_query->or_like('spiritual_and_social_background', '"caste":"'.$caste_1.'"');
		                            $recommended_query->or_like('spiritual_and_social_background', '"sub_caste":"'.$sub_caste_1.'"');
		                        $recommended_query->group_end(); // Close bracket

		                    } elseif( ! empty( $caste_1 ) ) {
		                        $recommended_query->or_like('spiritual_and_social_background', '"caste":"'.$caste_1.'"');
		                    }
		                }
		                if ( ! empty( $caste_2 ) || ! empty( $sub_caste_2 ) ) {
		                    if ( ! empty( $caste_2 ) && ! empty( $sub_caste_2 ) ) {
		                        $recommended_query->group_start(); // Open bracket
		                            $recommended_query->or_like('spiritual_and_social_background', '"caste":"'.$caste_2.'"');
		                            $recommended_query->or_like('spiritual_and_social_background', '"sub_caste":"'.$sub_caste_2.'"');
		                        $recommended_query->group_end(); // Close bracket

		                    } elseif( ! empty( $caste_2 ) ) {
		                        $recommended_query->or_like('spiritual_and_social_background', '"caste":"'.$caste_2.'"');
		                    }
		                }
		                if ( ! empty( $caste_3 ) || ! empty( $sub_caste_3 )  ) {
		                    if ( ! empty( $caste_3 ) && ! empty( $sub_caste_3 ) ) {
		                        $recommended_query->group_start(); // Open bracket
		                            $recommended_query->or_like('spiritual_and_social_background', '"caste":"'.$caste_3.'"');
		                            $recommended_query->or_like('spiritual_and_social_background', '"sub_caste":"'.$sub_caste_3.'"');
		                        $recommended_query->group_end(); // Close bracket

		                    } elseif( ! empty( $caste_3 ) ) {
		                        $recommended_query->or_like('spiritual_and_social_background', '"caste":"'.$caste_3.'"');
		                    }
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }

	            // location
	            $location = ! empty( $preferences['location'] ) ? ! empty( $preferences['location'] ) : PREFERENCE_ANY;
	            if ( $location == PREFERENCE_STRICT ) {
	                $present_address = json_decode( $member['present_address'], true );
	                $profile_state = ! empty( $present_address['state'] ) ? ! empty( $present_address['state'] ) : '';
	                $profile_district = ! empty( $present_address['district'] ) ? ! empty( $present_address['district'] ) : '';

	                $permanent_address = json_decode( $member['permanent_address'], true );
	                $profile_state = ! empty( $permanent_address['permanent_state'] ) ? ! empty( $permanent_address['permanent_state'] ) : '';
	                $profile_district = ! empty( $permanent_address['permanent_district'] ) ? ! empty( $permanent_address['permanent_district'] ) : '';

	                $state_1 = ! empty( $preferences['state_1'] ) ? ! empty( $preferences['state_1'] ) : $profile_state;
	                $state_2 = ! empty( $preferences['state_2'] ) ? ! empty( $preferences['state_2'] ) : $profile_state;
	                $state_3 = ! empty( $preferences['state_3'] ) ? ! empty( $preferences['state_3'] ) : $profile_state;

	                $district_1 = ! empty( $preferences['district_1'] ) ? ! empty( $preferences['district_1'] ) : $profile_district;
	                $district_2 = ! empty( $preferences['district_2'] ) ? ! empty( $preferences['district_2'] ) : $profile_district;
	                $district_3 = ! empty( $preferences['district_3'] ) ? ! empty( $preferences['district_3'] ) : $profile_district;

	                if ( ! empty( $state_1 )
	                	|| ! empty( $district_1 )

	                	|| ! empty( $state_2 )
	                	|| ! empty( $district_2 )

	                	|| ! empty( $state_3 )
	                	|| ! empty( $district_3 )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $state_1 ) || ! empty( $district_1 ) ) {
		                    if ( ! empty( $state_1 ) && ! empty( $district_1 ) ) {
		                        $recommended_query->group_start(); // Open bracket
		                            $recommended_query->or_like('present_address', '"state":"'.$state_1.'"');
		                            $recommended_query->or_like('present_address', '"district":"'.$district_1.'"');
		                        $recommended_query->group_end(); // Close bracket

		                    } elseif( ! empty( $state_1 ) ) {
		                        $recommended_query->or_like('present_address', '"state":"'.$state_1.'"');
		                    }
		                }
		                if ( ! empty( $state_2 ) || ! empty( $district_2 ) ) {
		                    if ( ! empty( $state_2 ) && ! empty( $district_2 ) ) {
		                        $recommended_query->group_start(); // Open bracket
		                            $recommended_query->or_like('present_address', '"state":"'.$state_2.'"');
		                            $recommended_query->or_like('present_address', '"district":"'.$district_2.'"');
		                        $recommended_query->group_end(); // Close bracket

		                    } elseif( ! empty( $state_2 ) ) {
		                        $recommended_query->or_like('present_address', '"state":"'.$state_2.'"');
		                    }
		                }
		                if ( ! empty( $state_3 ) || ! empty( $district_3 )  ) {
		                    if ( ! empty( $state_3 ) && ! empty( $district_3 ) ) {
		                        $recommended_query->group_start(); // Open bracket
		                            $recommended_query->or_like('present_address', '"state":"'.$state_3.'"');
		                            $recommended_query->or_like('present_address', '"district":"'.$district_3.'"');
		                        $recommended_query->group_end(); // Close bracket

		                    } elseif( ! empty( $state_3 ) ) {
		                        $recommended_query->or_like('present_address', '"state":"'.$state_3.'"');
		                    }
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }

	            // Annual Income
	            $annual_income = ! empty( $preferences['annual_income'] ) ? ! empty( $preferences['annual_income'] ) : PREFERENCE_ANY;
	            if ( $annual_income == PREFERENCE_STRICT ) {
	                $education_and_career = json_decode( $member['education_and_career'], true );
	                $annual_income_1 = ! empty( $preferences['annual_income_1'] ) ? ! empty( $preferences['annual_income_1'] ) : '';
	                $annual_income_2 = ! empty( $preferences['annual_income_2'] ) ? ! empty( $preferences['annual_income_2'] ) : '';
	                $annual_income_3 = ! empty( $preferences['annual_income_3'] ) ? ! empty( $preferences['annual_income_3'] ) : '';

	                if ( ! empty( $annual_income_1 )
	                	|| ! empty( $annual_income_2 )
	                	|| ! empty( $annual_income_3 )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $annual_income_1 ) ) {
		                    $recommended_query->or_like('education_and_career', '"annual_income":"'.$annual_income_1.'"');
		                }
		                if ( ! empty( $annual_income_2 ) ) {
		                    $recommended_query->or_like('education_and_career', '"annual_income":"'.$annual_income_2.'"');
		                }
		                if ( ! empty( $annual_income_3 ) ) {
		                    $recommended_query->or_like('education_and_career', '"annual_income":"'.$annual_income_3.'"');
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }

	            // Age/Physical
	            $age_physical = ! empty( $preferences['age_physical'] ) ? ! empty( $preferences['age_physical'] ) : PREFERENCE_ANY;
	            if ( $age_physical == PREFERENCE_STRICT ) {
	                $height = $member['height'];
	                $hair_color = ! empty( $preferences['hair_color'] ) ? ! empty( $preferences['hair_color'] ) : '';
	                $blood_group = ! empty( $preferences['blood_group'] ) ? ! empty( $preferences['blood_group'] ) : '';

	                if ( ! empty( $height )
	                	|| ! empty( $hair_color )
	                	|| ! empty( $blood_group )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $height ) ) {
		                    $recommended_query->where('height', $height);
		                }
		                if ( ! empty( $hair_color ) ) {
		                    $recommended_query->or_like('physical_attributes', '"hair_color":"'.$hair_color.'"');
		                }
		                if ( ! empty( $blood_group ) ) {
		                    $recommended_query->or_like('physical_attributes', '"blood_group":"'.$blood_group.'"');
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }

	            // Spiritual
	            /*
	            $annual_income = ! empty( $preferences['annual_income'] ) ? ! empty( $preferences['annual_income'] ) : PREFERENCE_ANY;
	            if ( $annual_income == PREFERENCE_STRICT ) {
	                $education_and_career = json_decode( $member['education_and_career'], true );
	                $annual_income_1 = ! empty( $preferences['annual_income_1'] ) ? ! empty( $preferences['annual_income_1'] ) : '';
	                $annual_income_2 = ! empty( $preferences['annual_income_2'] ) ? ! empty( $preferences['annual_income_2'] ) : '';
	                $annual_income_3 = ! empty( $preferences['annual_income_3'] ) ? ! empty( $preferences['annual_income_3'] ) : '';
	            }
	            */

	            // Family
	            $family_status = ! empty( $preferences['family_status'] ) ? ! empty( $preferences['family_status'] ) : PREFERENCE_ANY;
	            if ( $family_status == PREFERENCE_STRICT ) {
	                $spiritual_and_social_background = json_decode( $member['spiritual_and_social_background'], true );
	                $profile_family_status = ! empty( $spiritual_and_social_background['family_status'] ) ? ! empty( $spiritual_and_social_background['family_status'] ) : '';

	                $family_status_1 = ! empty( $preferences['family_status_1'] ) ? ! empty( $preferences['family_status_1'] ) : $profile_family_status;
	                $family_status_2 = ! empty( $preferences['family_status_2'] ) ? ! empty( $preferences['family_status_2'] ) : $profile_family_status;
	                $family_status_3 = ! empty( $preferences['family_status_3'] ) ? ! empty( $preferences['family_status_3'] ) : $profile_family_status;

	                if ( ! empty( $family_status_1 )
	                	|| ! empty( $family_status_2 )
	                	|| ! empty( $family_status_3 )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $family_status_1 ) ) {
		                    $recommended_query->or_like('spiritual_and_social_background', '"family_status":"'.$family_status_1.'"');
		                }
		                if ( ! empty( $family_status_2 ) ) {
		                    $recommended_query->or_like('spiritual_and_social_background', '"family_status":"'.$family_status_2.'"');
		                }
		                if ( ! empty( $family_status_3 ) ) {
		                    $recommended_query->or_like('spiritual_and_social_background', '"family_status":"'.$family_status_3.'"');
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }

	            // Habits
	            $partner_drinking_habits = ! empty( $preferences['partner_drinking_habits'] ) ? ! empty( $preferences['partner_drinking_habits'] ) : PREFERENCE_ANY;
	            if ( $partner_drinking_habits == PREFERENCE_STRICT ) {
	                $life_style = json_decode( $member['life_style'], true );
	                $profile_drink = ! empty( $life_style['drink'] ) ? ! empty( $life_style['drink'] ) : '';
	                $profile_smoke = ! empty( $life_style['smoke'] ) ? ! empty( $life_style['smoke'] ) : '';
	                $profile_diet = ! empty( $life_style['diet'] ) ? ! empty( $life_style['diet'] ) : '';

	                $drink = ! empty( $preferences['drink'] ) ? ! empty( $preferences['drink'] ) : $profile_drink;
	                $smoke = ! empty( $preferences['smoke'] ) ? ! empty( $preferences['smoke'] ) : $profile_smoke;
	                $diet = ! empty( $preferences['diet'] ) ? ! empty( $preferences['diet'] ) : $profile_diet;

	                if ( ! empty( $drink )
	                	|| ! empty( $smoke )
	                	|| ! empty( $diet )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $drink ) ) {
		                    $recommended_query->or_like('life_style', '"drink":"'.$drink.'"');
		                }
		                if ( ! empty( $smoke ) ) {
		                    $recommended_query->or_like('life_style', '"smoke":"'.$smoke.'"');
		                }
		                if ( ! empty( $diet ) ) {
		                    $recommended_query->or_like('life_style', '"diet":"'.$diet.'"');
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }
        	}

        	return $recommended_query->get();
		}
	}

	if ( ! function_exists('getRecommended') ) {
		function getRecommended( $member_id ) {
			$CI=& get_instance();
			$CI->load->database();

			$member = $CI->Crud_model->filter_one('member', 'member_id', $member_id);
        	$member = $member[0];

			$ignored_ids = $CI->Crud_model->get_type_name_by_id('member', $member_id, 'ignored');
			$ignored_ids = json_decode($ignored_ids, true);
			$ignored_by_ids = $CI->Crud_model->get_type_name_by_id('member', $member_id, 'ignored_by');
			$ignored_by_ids = json_decode($ignored_by_ids, true);


        	$preferences = json_decode( $member['preferences'], true );
        	$recommended_members = [];
        	$by_denomination = $by_caste = $by_location = $by_annual_income = $by_age = $by_spiritual = $by_family = $by_habits = [];

	        $recommended_query = $CI->db->from('member')
	        	->where('plan_until >= ', date('Y-m-d'))
	        	->where('member_id != ', $member_id)
	        	->where('membership', 2)
	        	->where('is_blocked', 'no')
	        	->where('email_verification_status', 1)
	        	->where('is_closed', 'no');
	        if ( ! empty( $ignored_ids ) ) {
	            $recommended_query->where_not_in('member_id', $ignored_ids);
	        }
	        if ( ! empty( $ignored_by_ids ) ) {
	            $recommended_query->where_not_in('member_id', $ignored_by_ids);
	        }

	        if ( ! empty( $preferences ) ) {
            	$preferences = $preferences[0];

            	// Denomination
	            $denomination = ! empty( $preferences['denomination'] ) ? ! empty( $preferences['denomination'] ) : PREFERENCE_ANY;
	            if ( $denomination == PREFERENCE_STRICT ) {
	                $spiritual_and_social_background = json_decode( $member['spiritual_and_social_background'], true );
	                $profile_denomination = ! empty( $spiritual_and_social_background['denomination'] ) ? ! empty( $spiritual_and_social_background['denomination'] ) : '';
	                $denomination_1 = ! empty( $preferences['denomination_1'] ) ? ! empty( $preferences['denomination_1'] ) : $profile_denomination;
	                $denomination_2 = ! empty( $preferences['denomination_2'] ) ? ! empty( $preferences['denomination_2'] ) : $profile_denomination;
	                $denomination_3 = ! empty( $preferences['denomination_3'] ) ? ! empty( $preferences['denomination_3'] ) : $profile_denomination;
	                if ( ! empty( $denomination_1 )
	                	|| ! empty( $denomination_2 )
	                	|| ! empty( $denomination_3 )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $denomination_1 ) ) {
		                    $recommended_query->or_like('spiritual_and_social_background', '"denomination":"'.$denomination_1.'"', 'both');
		                }
		                if ( ! empty( $denomination_2 ) ) {
		                    $recommended_query->or_like('spiritual_and_social_background', '"denomination":"'.$denomination_2.'"', 'both');
		                }
		                if ( ! empty( $denomination_3 ) ) {
		                    $recommended_query->or_like('spiritual_and_social_background', '"denomination":"'.$denomination_3.'"', 'both');
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }

	            // Caste
	            $caste = ! empty( $preferences['caste'] ) ? ! empty( $preferences['caste'] ) : PREFERENCE_ANY;
	            if ( $caste == PREFERENCE_STRICT ) {
	                $spiritual_and_social_background = json_decode( $member['spiritual_and_social_background'], true );
	                $profile_caste = ! empty( $spiritual_and_social_background['caste'] ) ? ! empty( $spiritual_and_social_background['caste'] ) : '';
	                $profile_sub_caste = ! empty( $spiritual_and_social_background['sub_caste'] ) ? ! empty( $spiritual_and_social_background['sub_caste'] ) : '';

	                $caste_1 = ! empty( $preferences['caste_1'] ) ? ! empty( $preferences['caste_1'] ) : $profile_caste;
	                $caste_2 = ! empty( $preferences['caste_2'] ) ? ! empty( $preferences['caste_2'] ) : $profile_caste;
	                $caste_3 = ! empty( $preferences['caste_3'] ) ? ! empty( $preferences['caste_3'] ) : $profile_caste;

	                $sub_caste_1 = ! empty( $preferences['sub_caste_1'] ) ? ! empty( $preferences['sub_caste_1'] ) : $profile_sub_caste;
	                $sub_caste_2 = ! empty( $preferences['sub_caste_2'] ) ? ! empty( $preferences['sub_caste_2'] ) : $profile_sub_caste;
	                $sub_caste_3 = ! empty( $preferences['sub_caste_3'] ) ? ! empty( $preferences['sub_caste_3'] ) : $profile_sub_caste;

	                if ( ! empty( $caste_1 )
	                	|| ! empty( $sub_caste_1 )

	                	|| ! empty( $caste_2 )
	                	|| ! empty( $sub_caste_2 )

	                	|| ! empty( $caste_3 )
	                	|| ! empty( $sub_caste_3 )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $caste_1 ) || ! empty( $sub_caste_1 ) ) {
		                    if ( ! empty( $caste_1 ) && ! empty( $sub_caste_1 ) ) {
		                        $recommended_query->group_start(); // Open bracket
		                            $recommended_query->or_like('spiritual_and_social_background', '"caste":"'.$caste_1.'"', 'both');
		                            $recommended_query->or_like('spiritual_and_social_background', '"sub_caste":"'.$sub_caste_1.'"', 'both');
		                        $recommended_query->group_end(); // Close bracket

		                    } elseif( ! empty( $caste_1 ) ) {
		                        $recommended_query->or_like('spiritual_and_social_background', '"caste":"'.$caste_1.'"', 'both');
		                    }
		                }
		                if ( ! empty( $caste_2 ) || ! empty( $sub_caste_2 ) ) {
		                    if ( ! empty( $caste_2 ) && ! empty( $sub_caste_2 ) ) {
		                        $recommended_query->group_start(); // Open bracket
		                            $recommended_query->or_like('spiritual_and_social_background', '"caste":"'.$caste_2.'"', 'both');
		                            $recommended_query->or_like('spiritual_and_social_background', '"sub_caste":"'.$sub_caste_2.'"', 'both');
		                        $recommended_query->group_end(); // Close bracket

		                    } elseif( ! empty( $caste_2 ) ) {
		                        $recommended_query->or_like('spiritual_and_social_background', '"caste":"'.$caste_2.'"', 'both');
		                    }
		                }
		                if ( ! empty( $caste_3 ) || ! empty( $sub_caste_3 )  ) {
		                    if ( ! empty( $caste_3 ) && ! empty( $sub_caste_3 ) ) {
		                        $recommended_query->group_start(); // Open bracket
		                            $recommended_query->or_like('spiritual_and_social_background', '"caste":"'.$caste_3.'"', 'both');
		                            $recommended_query->or_like('spiritual_and_social_background', '"sub_caste":"'.$sub_caste_3.'"', 'both');
		                        $recommended_query->group_end(); // Close bracket

		                    } elseif( ! empty( $caste_3 ) ) {
		                        $recommended_query->or_like('spiritual_and_social_background', '"caste":"'.$caste_3.'"', 'both');
		                    }
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }

	            // location
	            $location = ! empty( $preferences['location'] ) ? ! empty( $preferences['location'] ) : PREFERENCE_ANY;
	            if ( $location == PREFERENCE_STRICT ) {
	                $present_address = json_decode( $member['present_address'], true );
	                $profile_state = ! empty( $present_address['state'] ) ? ! empty( $present_address['state'] ) : '';
	                $profile_district = ! empty( $present_address['district'] ) ? ! empty( $present_address['district'] ) : '';

	                $permanent_address = json_decode( $member['permanent_address'], true );
	                $profile_state = ! empty( $permanent_address['permanent_state'] ) ? ! empty( $permanent_address['permanent_state'] ) : '';
	                $profile_district = ! empty( $permanent_address['permanent_district'] ) ? ! empty( $permanent_address['permanent_district'] ) : '';

	                $state_1 = ! empty( $preferences['state_1'] ) ? ! empty( $preferences['state_1'] ) : $profile_state;
	                $state_2 = ! empty( $preferences['state_2'] ) ? ! empty( $preferences['state_2'] ) : $profile_state;
	                $state_3 = ! empty( $preferences['state_3'] ) ? ! empty( $preferences['state_3'] ) : $profile_state;

	                $district_1 = ! empty( $preferences['district_1'] ) ? ! empty( $preferences['district_1'] ) : $profile_district;
	                $district_2 = ! empty( $preferences['district_2'] ) ? ! empty( $preferences['district_2'] ) : $profile_district;
	                $district_3 = ! empty( $preferences['district_3'] ) ? ! empty( $preferences['district_3'] ) : $profile_district;

	                if ( ! empty( $state_1 )
	                	|| ! empty( $district_1 )

	                	|| ! empty( $state_2 )
	                	|| ! empty( $district_2 )

	                	|| ! empty( $state_3 )
	                	|| ! empty( $district_3 )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $state_1 ) || ! empty( $district_1 ) ) {
		                    if ( ! empty( $state_1 ) && ! empty( $district_1 ) ) {
		                        $recommended_query->group_start(); // Open bracket
		                            $recommended_query->or_like('present_address', '"state":"'.$state_1.'"', 'both');
		                            $recommended_query->or_like('present_address', '"district":"'.$district_1.'"', 'both');
		                        $recommended_query->group_end(); // Close bracket

		                    } elseif( ! empty( $state_1 ) ) {
		                        $recommended_query->or_like('present_address', '"state":"'.$state_1.'"', 'both');
		                    }
		                }
		                if ( ! empty( $state_2 ) || ! empty( $district_2 ) ) {
		                    if ( ! empty( $state_2 ) && ! empty( $district_2 ) ) {
		                        $recommended_query->group_start(); // Open bracket
		                            $recommended_query->or_like('present_address', '"state":"'.$state_2.'"', 'both');
		                            $recommended_query->or_like('present_address', '"district":"'.$district_2.'"', 'both');
		                        $recommended_query->group_end(); // Close bracket

		                    } elseif( ! empty( $state_2 ) ) {
		                        $recommended_query->or_like('present_address', '"state":"'.$state_2.'"', 'both');
		                    }
		                }
		                if ( ! empty( $state_3 ) || ! empty( $district_3 )  ) {
		                    if ( ! empty( $state_3 ) && ! empty( $district_3 ) ) {
		                        $recommended_query->group_start(); // Open bracket
		                            $recommended_query->or_like('present_address', '"state":"'.$state_3.'"', 'both');
		                            $recommended_query->or_like('present_address', '"district":"'.$district_3.'"', 'both');
		                        $recommended_query->group_end(); // Close bracket

		                    } elseif( ! empty( $state_3 ) ) {
		                        $recommended_query->or_like('present_address', '"state":"'.$state_3.'"', 'both');
		                    }
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }

	            // Annual Income
	            $annual_income = ! empty( $preferences['annual_income'] ) ? ! empty( $preferences['annual_income'] ) : PREFERENCE_ANY;
	            if ( $annual_income == PREFERENCE_STRICT ) {
	                $education_and_career = json_decode( $member['education_and_career'], true );
	                $annual_income_1 = ! empty( $preferences['annual_income_1'] ) ? ! empty( $preferences['annual_income_1'] ) : '';
	                $annual_income_2 = ! empty( $preferences['annual_income_2'] ) ? ! empty( $preferences['annual_income_2'] ) : '';
	                $annual_income_3 = ! empty( $preferences['annual_income_3'] ) ? ! empty( $preferences['annual_income_3'] ) : '';

	                if ( ! empty( $annual_income_1 )
	                	|| ! empty( $annual_income_2 )
	                	|| ! empty( $annual_income_3 )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $annual_income_1 ) ) {
		                    $recommended_query->or_like('education_and_career', '"annual_income":"'.$annual_income_1.'"', 'both');
		                }
		                if ( ! empty( $annual_income_2 ) ) {
		                    $recommended_query->or_like('education_and_career', '"annual_income":"'.$annual_income_2.'"', 'both');
		                }
		                if ( ! empty( $annual_income_3 ) ) {
		                    $recommended_query->or_like('education_and_career', '"annual_income":"'.$annual_income_3.'"', 'both');
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }

	            // Age/Physical
	            $age_physical = ! empty( $preferences['age_physical'] ) ? ! empty( $preferences['age_physical'] ) : PREFERENCE_ANY;
	            if ( $age_physical == PREFERENCE_STRICT ) {
	                $height = $member['height'];
	                $hair_color = ! empty( $preferences['hair_color'] ) ? ! empty( $preferences['hair_color'] ) : '';
	                $blood_group = ! empty( $preferences['blood_group'] ) ? ! empty( $preferences['blood_group'] ) : '';

	                if ( ! empty( $height )
	                	|| ! empty( $hair_color )
	                	|| ! empty( $blood_group )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $height ) ) {
		                    $recommended_query->where('height', $height);
		                }
		                if ( ! empty( $hair_color ) ) {
		                    $recommended_query->or_like('physical_attributes', '"hair_color":"'.$hair_color.'"', 'both');
		                }
		                if ( ! empty( $blood_group ) ) {
		                    $recommended_query->or_like('physical_attributes', '"blood_group":"'.$blood_group.'"', 'both');
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }

	            // Spiritual
	            /*
	            $annual_income = ! empty( $preferences['annual_income'] ) ? ! empty( $preferences['annual_income'] ) : PREFERENCE_ANY;
	            if ( $annual_income == PREFERENCE_STRICT ) {
	                $education_and_career = json_decode( $member['education_and_career'], true );
	                $annual_income_1 = ! empty( $preferences['annual_income_1'] ) ? ! empty( $preferences['annual_income_1'] ) : '';
	                $annual_income_2 = ! empty( $preferences['annual_income_2'] ) ? ! empty( $preferences['annual_income_2'] ) : '';
	                $annual_income_3 = ! empty( $preferences['annual_income_3'] ) ? ! empty( $preferences['annual_income_3'] ) : '';
	            }
	            */

	            // Family
	            $family_status = ! empty( $preferences['family_status'] ) ? ! empty( $preferences['family_status'] ) : PREFERENCE_ANY;
	            if ( $family_status == PREFERENCE_STRICT ) {
	                $spiritual_and_social_background = json_decode( $member['spiritual_and_social_background'], true );
	                $profile_family_status = ! empty( $spiritual_and_social_background['family_status'] ) ? ! empty( $spiritual_and_social_background['family_status'] ) : '';

	                $family_status_1 = ! empty( $preferences['family_status_1'] ) ? ! empty( $preferences['family_status_1'] ) : $profile_family_status;
	                $family_status_2 = ! empty( $preferences['family_status_2'] ) ? ! empty( $preferences['family_status_2'] ) : $profile_family_status;
	                $family_status_3 = ! empty( $preferences['family_status_3'] ) ? ! empty( $preferences['family_status_3'] ) : $profile_family_status;

	                if ( ! empty( $family_status_1 )
	                	|| ! empty( $family_status_2 )
	                	|| ! empty( $family_status_3 )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $family_status_1 ) ) {
		                    $recommended_query->or_like('spiritual_and_social_background', '"family_status":"'.$family_status_1.'"', 'both');
		                }
		                if ( ! empty( $family_status_2 ) ) {
		                    $recommended_query->or_like('spiritual_and_social_background', '"family_status":"'.$family_status_2.'"', 'both');
		                }
		                if ( ! empty( $family_status_3 ) ) {
		                    $recommended_query->or_like('spiritual_and_social_background', '"family_status":"'.$family_status_3.'"', 'both');
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }

	            // Habits
	            $partner_drinking_habits = ! empty( $preferences['partner_drinking_habits'] ) ? ! empty( $preferences['partner_drinking_habits'] ) : PREFERENCE_ANY;
	            if ( $partner_drinking_habits == PREFERENCE_STRICT ) {
	                $life_style = json_decode( $member['life_style'], true );
	                $profile_drink = ! empty( $life_style['drink'] ) ? ! empty( $life_style['drink'] ) : '';
	                $profile_smoke = ! empty( $life_style['smoke'] ) ? ! empty( $life_style['smoke'] ) : '';
	                $profile_diet = ! empty( $life_style['diet'] ) ? ! empty( $life_style['diet'] ) : '';

	                $drink = ! empty( $preferences['drink'] ) ? ! empty( $preferences['drink'] ) : $profile_drink;
	                $smoke = ! empty( $preferences['smoke'] ) ? ! empty( $preferences['smoke'] ) : $profile_smoke;
	                $diet = ! empty( $preferences['diet'] ) ? ! empty( $preferences['diet'] ) : $profile_diet;

	                if ( ! empty( $drink )
	                	|| ! empty( $smoke )
	                	|| ! empty( $diet )
	            	) {
		                $recommended_query->group_start(); // Open bracket
		                if ( ! empty( $drink ) ) {
		                    $recommended_query->or_like('life_style', '"drink":"'.$drink.'"', 'both');
		                }
		                if ( ! empty( $smoke ) ) {
		                    $recommended_query->or_like('life_style', '"smoke":"'.$smoke.'"', 'both');
		                }
		                if ( ! empty( $diet ) ) {
		                    $recommended_query->or_like('life_style', '"diet":"'.$diet.'"', 'both');
		                }
		                $recommended_query->group_end(); // Close bracket
	            	}
	            }
        	}

        	return $recommended_query->get();
		}
	}

	/**
	 * Prepare flash message
	 *
	 */
	function prepare_flashmessage($msg, $type = 2)
	{
		$CI	=&	get_instance();

		$returnmsg='';
		switch($type){
			case 0: $returnmsg = " <div class='container'>
										<div class='alert alert-success'>
											<a href='#' class='close' data-dismiss='alert'>&times;</a>
											<strong>".translate('success')."!</strong> ". $msg."
										</div>
									</div> -->";
				break;
			case 1: $returnmsg = " <div class='container'>
										<div class='alert alert-danger'>
											<a href='#' class='close' data-dismiss='alert'>&times;</a>
											<strong>".translate('error')."!</strong> ". $msg."
										</div>
									</div> -->";
				break;
			case 2: $returnmsg = " <div class='container'>
										<div class='alert alert-info'>
											<a href='#' class='close' data-dismiss='alert'>&times;</a>
											<strong>".translate('info')."!</strong> ". $msg."
										</div>
									</div> -->";
				break;
			case 3: $returnmsg = " <div class='container'>
										<div class='alert alert-warning'>
											<a href='#' class='close' data-dismiss='alert'>&times;</a>
											<strong>".translate('warning')."!</strong> ". $msg."
										</div>
									</div>";
				break;
		}

		$CI->session->set_flashdata("message", $returnmsg);
	}

	if ( ! function_exists('profileHideUsers'))
	{
		function profileHideUsers(){
			$CI=& get_instance();
			$CI->load->database();

			$query = "SELECT * FROM member m INNER JOIN plan p ON m.current_plan_id = p.plan_id WHERE p.profile_hide = 'Yes' AND m.plan_until >= DATE(NOW())";
			$members = $CI->db->query($query)->result();
			$hide_ids = [];
			if ( $members ) {
				foreach ($members as $member) {
					$hide_ids[] = $member->member_id;
				}
			}
			return $hide_ids;
		}
	}
